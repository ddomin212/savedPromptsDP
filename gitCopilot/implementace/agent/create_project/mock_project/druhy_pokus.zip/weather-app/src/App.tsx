import React from 'react';
import CurrentWeather from './components/CurrentWeather';
import WeatherForecast from './components/WeatherForecast';

function App() {
  return (
    <div className="App">
      <CurrentWeather />
      <WeatherForecast />
    </div>
  );
}

export default App;