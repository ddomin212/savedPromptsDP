import React, { useEffect, useState } from 'react';
import { getCurrentWeather } from '../api/OpenWeatherAPI';
import { formatTemperature } from '../utils/formatWeatherData';

const CurrentWeather = () => {
  const [weatherData, setWeatherData] = useState(null);

  useEffect(() => {
    getCurrentWeather()
      .then(data => setWeatherData(data))
      .catch(error => console.error('Error:', error));
  }, []);

  if (!weatherData) {
    return <div>Loading...</div>;
  }

  return (
    <div className="current-weather">
      <h1>{weatherData.name}</h1>
      <p>{formatTemperature(weatherData.main.temp)}</p>
      <p>{weatherData.weather[0].description}</p>
    </div>
  );
};

export default CurrentWeather;