export function formatTemperature(tempInKelvin: number): string {
  const tempInCelsius = tempInKelvin - 273.15;
  return `${tempInCelsius.toFixed(1)}°C`;
}

export function formatWindSpeed(speedInMetersPerSecond: number): string {
  const speedInKilometersPerHour = speedInMetersPerSecond * 3.6;
  return `${speedInKilometersPerHour.toFixed(1)} km/h`;
}