import React, { useEffect, useState } from 'react';
import { getWeatherForecast } from '../api/OpenWeatherAPI';
import { formatTemperature } from '../utils/formatWeatherData';

const WeatherForecast = () => {
  const [forecast, setForecast] = useState(null);

  useEffect(() => {
    getWeatherForecast()
      .then(data => setForecast(data))
      .catch(error => console.error(error));
  }, []);

  if (!forecast) {
    return <div>Loading...</div>;
  }

  return (
    <div className="forecast">
      {forecast.list.map((weather, index) => (
        <div key={index} className="forecast-item">
          <div>{new Date(weather.dt * 1000).toLocaleDateString()}</div>
          <div>{formatTemperature(weather.main.temp)}</div>
          <div>{weather.weather[0].description}</div>
        </div>
      ))}
    </div>
  );
};

export default WeatherForecast;