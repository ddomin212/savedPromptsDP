import axios from 'axios';

const API_KEY = 'your_openweather_api_key';
const BASE_URL = 'http://api.openweathermap.org/data/2.5';

export const getCurrentWeather = (city: string) => {
  return axios.get(`${BASE_URL}/weather?q=${city}&appid=${API_KEY}`);
}

export const getWeatherForecast = (city: string) => {
  return axios.get(`${BASE_URL}/forecast?q=${city}&appid=${API_KEY}`);
}