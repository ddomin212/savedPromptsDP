# Weather App

This is a simple weather application built with React, Tailwind CSS, and OpenWeatherAPI. It displays the current weather and forecast for a given location.

## Installation

First, clone the repository:

```
git clone https://github.com/yourusername/weather-app.git
```

Then, navigate into the project directory and install the dependencies:

```
cd weather-app
npm install
```

## Usage

To start the development server, run:

```
npm start
```

The application will be available at `http://localhost:3000`.

## Configuration

You will need to obtain an API key from OpenWeatherAPI and add it to a `.env` file in the root of the project:

```
REACT_APP_OPENWEATHER_API_KEY=your_api_key_here
```

## Components

- `CurrentWeather`: Fetches and displays the current weather.
- `WeatherForecast`: Fetches and displays the weather forecast.

## API

The `OpenWeatherAPI` module contains functions for making API calls to the OpenWeatherAPI.

## Utilities

The `formatWeatherData` module contains utility functions for formatting the weather data.

## Styles

The application uses Tailwind CSS for styling. The configuration is in `tailwind.config.js`.

## TypeScript

The project is written in TypeScript. The configuration is in `tsconfig.json`.

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License

[MIT](https://choosealicense.com/licenses/mit/)