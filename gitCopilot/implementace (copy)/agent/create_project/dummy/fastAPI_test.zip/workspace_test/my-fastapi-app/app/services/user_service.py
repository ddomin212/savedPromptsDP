from fastapi import HTTPException
from app.models.user import User

users = []

def get_all_users():
    return users

def get_user(user_id: int):
    for user in users:
        if user.id == user_id:
            return user
    raise HTTPException(status_code=404, detail="User not found")

def create_user(user: User):
    users.append(user)
    return user

def update_user(user_id: int, user: User):
    for index, existing_user in enumerate(users):
        if existing_user.id == user_id:
            users[index] = user
            return user
    raise HTTPException(status_code=404, detail="User not found")

def delete_user(user_id: int):
    for index, existing_user in enumerate(users):
        if existing_user.id == user_id:
            users.pop(index)
            return existing_user
    raise HTTPException(status_code=404, detail="User not found")