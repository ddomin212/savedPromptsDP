from fastapi import APIRouter
from app.services import user_service

router = APIRouter()

@router.get("/users/{user_id}")
async def read_user(user_id: int):
    return user_service.get_user(user_id)

@router.post("/users/")
async def create_user(user: user_service.User):
    return user_service.create_user(user)

@router.put("/users/{user_id}")
async def update_user(user_id: int, user: user_service.User):
    return user_service.update_user(user_id, user)

@router.delete("/users/{user_id}")
async def delete_user(user_id: int):
    return user_service.delete_user(user_id)