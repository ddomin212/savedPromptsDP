import React, { useEffect, useState } from 'react';
import axios from 'axios';

const WeatherDisplay = () => {
  const [weatherData, setWeatherData] = useState(null);

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const response = await axios.get('/api/weather');
        setWeatherData(response.data);
      } catch (error) {
        console.error('Failed to fetch weather data:', error);
      }
    };

    fetchWeather();
  }, []);

  if (!weatherData) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h2>Current Weather</h2>
      <p>{`Temperature: ${weatherData.temperature}`}</p>
      <p>{`Humidity: ${weatherData.humidity}`}</p>
      <p>{`Wind Speed: ${weatherData.windSpeed}`}</p>
    </div>
  );
};

export default WeatherDisplay;