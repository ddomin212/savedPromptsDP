import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ForecastDisplay = () => {
    const [forecast, setForecast] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:8000/forecast')
            .then(response => {
                setForecast(response.data);
            })
            .catch(error => {
                console.error(`Error fetching data: ${error}`);
            })
    }, []);

    return (
        <div>
            <h2>Forecast</h2>
            {forecast.map((day, index) => (
                <div key={index}>
                    <h3>{day.date}</h3>
                    <p>{day.description}</p>
                    <p>{`Temperature: ${day.temperature}`}</p>
                </div>
            ))}
        </div>
    );
};

export default ForecastDisplay;