import React, { useState, useEffect } from 'react';
import WeatherDisplay from './components/WeatherDisplay';
import ForecastDisplay from './components/ForecastDisplay';

function App() {
  const [weatherData, setWeatherData] = useState(null);
  const [forecastData, setForecastData] = useState(null);

  useEffect(() => {
    fetch('/weather')
      .then(response => response.json())
      .then(data => setWeatherData(data));

    fetch('/forecast')
      .then(response => response.json())
      .then(data => setForecastData(data));
  }, []);

  return (
    <div className="App">
      {weatherData && <WeatherDisplay data={weatherData} />}
      {forecastData && <ForecastDisplay data={forecastData} />}
    </div>
  );
}

export default App;