# Weather App Backend

This is the backend for the Weather App. It is built with FastAPI and fetches data from a weather API.

## Setup

1. Install the dependencies:

```bash
pip install -r requirements.txt
```

2. Set up the environment variables in a `.env` file. You will need an API key from a weather service:

```bash
WEATHER_API_KEY=your_api_key
```

3. Run the server:

```bash
uvicorn app.main:app --reload
```

## API Routes

- `GET /weather/current`: Fetches the current weather.
- `GET /weather/forecast`: Fetches the weather forecast.

## Testing

To run the tests, use the following command:

```bash
pytest
```
```

Please replace `your_api_key` with your actual API key from the weather service.