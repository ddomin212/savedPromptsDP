from fastapi.testclient import TestClient
import pytest
from main import app

client = TestClient(app)

def test_get_current_weather():
    response = client.get("/weather/current")
    assert response.status_code == 200
    assert "temperature" in response.json()
    assert "description" in response.json()

def test_get_forecast():
    response = client.get("/weather/forecast")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    assert "temperature" in response.json()[0]
    assert "description" in response.json()[0]