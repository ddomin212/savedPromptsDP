from pydantic import BaseModel

class Weather(BaseModel):
    temperature: float
    humidity: float
    pressure: float
    description: str

class Forecast(BaseModel):
    date: str
    temperature: float
    description: str