from fastapi import APIRouter, HTTPException
from typing import Optional
import requests
import os

router = APIRouter()

@router.get("/weather/{city}")
async def get_weather(city: str, days: Optional[int] = 1):
    api_key = os.getenv("WEATHER_API_KEY")
    base_url = "http://api.weatherapi.com/v1/forecast.json"

    response = requests.get(f"{base_url}?key={api_key}&q={city}&days={days}")

    if response.status_code != 200:
        raise HTTPException(status_code=404, detail="Weather not found")

    return response.json()